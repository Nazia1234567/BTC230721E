package com;

import org.testng.annotations.Test;

public class SmokeTest extends BaseTest {
	@Test
	public void buyAShirt() {
		System.out.println("BuyAShirt");
	}
	@Test
	public void buyAPant() {
		System.out.println("BuyAShirt");
	}
}
