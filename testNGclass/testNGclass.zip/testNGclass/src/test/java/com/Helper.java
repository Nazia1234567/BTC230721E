package com;

public class Helper {
	public static void screenShot() {
		
	}

}
